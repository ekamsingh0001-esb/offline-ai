"""
Offline AI Assistant
Requirements:
  1. Install Ollama from https://ollama.com/download
  2. Run: ollama pull llama3.2:1b
  3. Run: python -m pip install ollama
  4. Run: python offline_ai.py

After the model is downloaded, chatting works without internet.
"""
import tkinter as tk
from tkinter import scrolledtext, messagebox
import threading

try:
    import ollama
except ImportError:
    ollama = None

MODEL = "llama3.2:1b"

SYSTEM_PROMPT = (
    "You are a helpful offline AI assistant. Explain concepts clearly, "
    "help with Python and computer science, and answer concisely. "
    "If you are unsure, say so rather than inventing facts."
)

class OfflineAIApp:
    def __init__(self, root):
        self.root = root
        self.root.title("My Offline AI Assistant")
        self.root.geometry("820x650")
        self.root.minsize(620, 480)
        self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        self.busy = False

        header = tk.Frame(root, padx=16, pady=12, bg="#172033")
        header.pack(fill="x")
        tk.Label(
            header, text="MY OFFLINE AI", font=("Segoe UI", 17, "bold"),
            fg="white", bg="#172033"
        ).pack(anchor="w")
        tk.Label(
            header, text=f"Local model: {MODEL}  •  Works offline after setup",
            font=("Segoe UI", 9), fg="#cbd5e1", bg="#172033"
        ).pack(anchor="w", pady=(3, 0))

        self.chat = scrolledtext.ScrolledText(
            root, wrap=tk.WORD, state="disabled",
            font=("Segoe UI", 11), padx=14, pady=12,
            bg="#f7f8fb", fg="#182033", relief="flat"
        )
        self.chat.pack(fill="both", expand=True, padx=12, pady=(12, 8))
        self.chat.tag_config("you", foreground="#155eef", font=("Segoe UI", 10, "bold"))
        self.chat.tag_config("ai", foreground="#13804a", font=("Segoe UI", 10, "bold"))
        self.chat.tag_config("body", foreground="#182033")
        self.chat.tag_config("muted", foreground="#687386", font=("Segoe UI", 9, "italic"))

        bottom = tk.Frame(root, padx=12, pady=10)
        bottom.pack(fill="x")
        self.entry = tk.Text(bottom, height=3, wrap=tk.WORD, font=("Segoe UI", 11), relief="solid", bd=1)
        self.entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.entry.bind("<Control-Return>", self.send_event)
        self.send_btn = tk.Button(
            bottom, text="Send", command=self.send,
            bg="#2457e6", fg="white", activebackground="#1744bd",
            activeforeground="white", relief="flat", padx=20, pady=10,
            font=("Segoe UI", 10, "bold"), cursor="hand2"
        )
        self.send_btn.pack(side="right", anchor="s")

        footer = tk.Frame(root, padx=14, pady=(0, 10))
        footer.pack(fill="x")
        tk.Label(footer, text="Enter a message • Ctrl+Enter to send", fg="#687386",
                 font=("Segoe UI", 9)).pack(side="left")
        tk.Button(footer, text="Clear chat", command=self.clear_chat, relief="flat",
                  fg="#475569", cursor="hand2").pack(side="right")

        self.add_message("AI", "Hi! I'm your offline AI assistant. Ask me a question whenever you're ready.")
        self.entry.focus_set()

    def add_message(self, who, text, tag=None):
        self.chat.configure(state="normal")
        self.chat.insert(tk.END, f"{who}\n", tag or ("ai" if who == "AI" else "you"))
        self.chat.insert(tk.END, text + "\n\n", "body")
        self.chat.configure(state="disabled")
        self.chat.see(tk.END)

    def add_status(self, text):
        self.chat.configure(state="normal")
        self.chat.insert(tk.END, text + "\n\n", "muted")
        self.chat.configure(state="disabled")
        self.chat.see(tk.END)

    def send_event(self, event):
        self.send()
        return "break"

    def send(self):
        if self.busy:
            return
        prompt = self.entry.get("1.0", tk.END).strip()
        if not prompt:
            return
        self.entry.delete("1.0", tk.END)
        self.add_message("You", prompt)
        if prompt.lower() in {"exit", "quit", "bye"}:
            self.add_message("AI", "Goodbye!")
            return

        if ollama is None:
            messagebox.showerror(
                "Missing Python package",
                "Install the Python package first:\n\npython -m pip install ollama"
            )
            return

        self.messages.append({"role": "user", "content": prompt})
        self.busy = True
        self.send_btn.configure(state="disabled", text="Thinking…")
        self.add_status("Thinking…")
        threading.Thread(target=self.ask_model, daemon=True).start()

    def ask_model(self):
        try:
            response = ollama.chat(model=MODEL, messages=self.messages)
            answer = response["message"]["content"]
            self.messages.append({"role": "assistant", "content": answer})
            self.root.after(0, lambda: self.finish_answer(answer))
        except Exception as exc:
            error = (
                f"Couldn't contact the local model.\n\n"
                f"Check that Ollama is installed and running, then run:\n"
                f"ollama pull {MODEL}\n\nDetails: {exc}"
            )
            self.root.after(0, lambda: self.finish_answer(error))
        finally:
            self.root.after(0, self.finish_request)

    def finish_answer(self, answer):
        self.add_message("AI", answer)

    def finish_request(self):
        self.busy = False
        self.send_btn.configure(state="normal", text="Send")
        self.entry.focus_set()

    def clear_chat(self):
        if self.busy:
            messagebox.showinfo("Please wait", "Wait for the current answer to finish.")
            return
        self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        self.chat.configure(state="normal")
        self.chat.delete("1.0", tk.END)
        self.chat.configure(state="disabled")
        self.add_message("AI", "Chat cleared. What would you like to ask?")

if __name__ == "__main__":
    root = tk.Tk()
    app = OfflineAIApp(root)
    root.mainloop()
