MY OFFLINE AI ASSISTANT — WINDOWS SETUP

WHAT'S INCLUDED
- offline_ai.py: desktop chat interface
- setup_windows.bat: installs the Python Ollama package
- run_ai.bat: launches the chat interface

REQUIREMENTS
- Windows 10/11
- Python 3.10 or newer
- Ollama for Windows
- A model download (one-time internet connection)

INSTALL
1. Extract this ZIP folder.
2. Double-click setup_windows.bat.
3. Install Ollama from https://ollama.com/download if not already installed.
4. Open Command Prompt and run:
       ollama pull llama3.2:1b
   Wait for the download to complete.
5. Double-click run_ai.bat.

OFFLINE USE
Once Ollama and the model are installed, you can disconnect from the internet
and run run_ai.bat. Ollama must be running locally.

TROUBLESHOOTING
- "ollama not found": install Ollama and reopen Command Prompt.
- Model missing: run `ollama pull llama3.2:1b`.
- Python package missing: run `python -m pip install ollama`.
- Slow responses: close other apps. Small models are less capable than ChatGPT.
- This starter version keeps conversation context in memory only while the app runs.

PRIVACY
Prompts are sent to the local Ollama service on your own computer. This app does
not intentionally send prompts to a remote AI service. The model download itself
requires internet.
