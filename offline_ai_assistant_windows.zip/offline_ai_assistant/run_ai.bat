@echo off
title My Offline AI Assistant
cd /d "%~dp0"
python offline_ai.py
if errorlevel 1 (
  echo.
  echo If a module is missing, run setup_windows.bat first.
  pause
)
