@echo off
title Setup My Offline AI
echo ==========================================
echo       SETTING UP MY OFFLINE AI
echo ==========================================
echo.
where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found. Install Python 3.10 or newer from:
  echo https://www.python.org/downloads/windows/
  echo During installation, tick "Add Python to PATH".
  pause
  exit /b 1
)
python -m pip install --upgrade pip
python -m pip install ollama
echo.
echo Next, install Ollama from https://ollama.com/download
echo Then run this command in a terminal:
echo   ollama pull llama3.2:1b
echo.
echo After the model download finishes, double-click run_ai.bat.
pause
